# This is the default mirror settings used by my site:
# src.doc.ic.ac.uk (146.169.2.1)
# This is home of the UKUUG Software Distribution Service
#
# Lee McLoughlin <lmjm@doc.ic.ac.uk>

# You should be able to use this at other sites.  You should only have
# to change bits that reference this site so look for doc.ic below.

package=security_win_tue_nl
	# The LOCAL hostname - if not the same as `hostname`
	# (I advertise the name src.doc.ic.ac.uk but the machine is
	#  really puffin.doc.ic.ac.uk.)
	hostname=mofet.macam98.ac.il
	# remote site
	site=ftp.win.tue.nl
	# Keep all local_dirs relative to here
	local_dir=/usr/local/mirrors/security/ftp.win.tue.nl
	remote_password=limor@xpert.com
	remote_dir=/pub/security
	mail_to=limor@xpert.com
	timeout=200
	# Don't mirror file modes.  Set all dirs/files to these
	#dir_mode=0755
	#file_mode=0444
	# By defaults files are owned by root.zero
	user=0
	group=0
#	# Keep a log file in each updated directory
#	update_log=.mirror
	update_log=
	# Don't overwrite my mirror log with the remote one.
	# Don't pull back any of their mirror temporary files.
	# Don't touch anything whose name begins with a space!
	# nor any FSP or gopher files...
	exclude_patt=(^|/)(\.mirror$|core$|\.cap|\.in\..*\.$|MIRROR.LOG|#.*#|\.FSP|\.cache|\.zipped|\.notar|\.message|lost+found/|\ )
	# Try to compress everything
	#compress_patt=.
	compress_patt=aaaaaaaaaaaaaaaaaaaaa_this_will_cause_nothing_to_compress
	compress_prog=gzip
	# Don't compress information files, files that don't benifit from
	# being compressed, files that tell ftpd, gopher, wais... to do things,
	# the sources for compression programs...
	# (Note this is the only regexp that is case insensitive.)
	# z matches compress/pack/gzip, gz for gzip. (built into perl)
	# taz/tgz is compressed or gzipped tar files
	# arc, arj, lzh, zip and zoo are pc and/or amiga archives.
	# sea are mac archives.
	# vms used -z instead of .z.  stupid vms.
	# shk is multimedia? used on apple2s.
	compress_excl+|-z(\d+)?$|\.tgz|_tgz|\.tar\.Z|\.tar\.gz|\.taz$|\.arc$|\.zip$|\.lzh$|\.zoo$|\.exe$|\.lha$|\.zom$|\.gif$|\.jpeg$|\.jpg$|\.mpeg$|\.au$|\.shk$|read.*me|index|info|faq|gzip|compress|(^|/)\.\.?$
	# Don't delete own mirror log, .notar or .cache files (incl in subdirs)
#	delete_excl=(^|/)\.(mirror|notar|cache)$
	# Ignore any local readme and .mirror files
	local_ignore=README.doc.ic|(^|/)\.(mirror|notar)$
	# Automatically delete local copies of files that the
	# remote site has zapped
	do_deletes=true
	max_delete_files=5000
	max_delete_dirs=5000
